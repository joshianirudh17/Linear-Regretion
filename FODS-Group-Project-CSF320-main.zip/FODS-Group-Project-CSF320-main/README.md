# FODS-Group-Project-CSF320

Group Members: <br>
Avinash Gondela <br>
Akhilesh Senapati <br>
Vaibhav Mishra <br>

The project consists of 2 parts: <br>
1) Aims to use linear regression from scratch to predict house prices. <br>
2) To implement polynomial regression from scratch using Gradient and Schochastic Gradient Descent. <br>


Data preprocessing techniques used: Normalisation, Standardisation <br>
Data visualisation done using seaborn and matplotlib <br>
Regularisation used: Ridge and Lasso <br>
Used Greedy Forward and Greedy Backward Feature selection for finding optimal subsets of attributes.
